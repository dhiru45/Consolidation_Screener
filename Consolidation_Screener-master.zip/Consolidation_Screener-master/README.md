# Consolidation_Screener
A stock screener that detect consolidation based on a Bollinger Bands and Keltner channels
